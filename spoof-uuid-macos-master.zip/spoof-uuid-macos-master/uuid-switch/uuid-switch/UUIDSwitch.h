//
//  uuid-switch.h
//  uuid-switch
//
//  Created by Valentin Radu on 08/04/2017.
//  Copyright © 2017 Valentin Radu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for uuid-switch.
FOUNDATION_EXPORT double uuid_switchVersionNumber;

//! Project version string for uuid-switch.
FOUNDATION_EXPORT const unsigned char uuid_switchVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <uuid_switch/PublicHeader.h>


